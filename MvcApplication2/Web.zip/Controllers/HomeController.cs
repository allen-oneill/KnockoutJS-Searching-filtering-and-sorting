﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;
using Newtonsoft.Json;

namespace MvcApplication2.Controllers
{
    public class HomeController : Controller
    {

        //public JsonResult ClientAjaxLoader()
        public string ClientAjaxLoader()
        {
            ClientModel cm = new ClientModel();
            ClientList cl = new ClientList();
            cl.Clients.AddRange(cm.GetClients());
            var jsonData = JsonConvert.SerializeObject(cl);
            //var s = jsonData.Substring(8, jsonData.Length-9); // remove the prefix for "list:"
            return jsonData;
            //return Json(jsonData, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}

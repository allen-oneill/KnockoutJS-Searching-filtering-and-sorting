﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace MvcApplication2.Models
{
    public class ClientList 
    {
    public List<ClientModel> Clients {get; set;}

    public ClientList()
    {
        Clients = new List<ClientModel>();
    }

    }

    public class ClientModel
    {
        public string ClientName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }


        public List<ClientModel> GetClients()
        {
            List<ClientModel> rslt = new List<ClientModel>();
            Random rnd = new Random();
            for (int i = 0; i < 1000; i++)
            {
                int r = rnd.Next(1, 100);
                ClientModel cm = new ClientModel();
                cm.ClientName = "Name " + i.ToString();
                cm.Address = "Address " + i.ToString();
                cm.Phone = "Phone " + r.ToString();
                rslt.Add(cm);
            }
            return rslt;        
        }

    }

    
}